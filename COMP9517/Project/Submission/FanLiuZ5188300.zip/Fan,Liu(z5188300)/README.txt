******************
******README******
******************

***This README file is for Fan, Liu Unet patch.ipynb***

Basically, there are ten main function in this code as following: 

* Import the library needed
* Read the file and doing patch Sampling
* Data augmentation
* Unet model initialize
* Loss function
* Compile and training
* Visualize the loss and accuracy
* Generate the testing data
* Predict the testing data
* Merge the result and save

And there are some comment block that are using on check the function is work correctly.

Code included:

*This code is for using Unet model and add the patch sampling to improve the output result.

Require install the following library:

* numpy
* pandas
* cv2
* tensorflow
* tifffile
* sklearn
* matplotlib
* zipfile

How to running:

*** Our prject is developing on the Kaggle's kernel ***

* Running on Kaggle's kernel, make sure you already uploaded 
the whole file images and labels on the kaggle's kernel and named images and labels.

* If you finish run all the file, there will a result document generated, and the output document inside which has a tif that included all the predict for 30 images.



