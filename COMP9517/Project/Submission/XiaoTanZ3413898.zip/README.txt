
#################################
####### Machine Learning ########
#################################

Code filename: "9517_ML.py"

The code for machine learning algorithm (LBP+RF) were developed and tested under Python 3.4.3 with following packages:
    - numpy 1.15.4
    - pandas
    - skimage
    - Scikit-learn
    - pickle, argparse

There are 5 arguments needed to run the code:
    -i: Path to train images, in .dcm format.
    -l: Path to label, which is the csv file in the same folder as train images
    -m: Path to save the model, with model name ending with '.p'
    -t: Path to test images
    -o: Path to output directory

e.g. python3 9517_ML.py -i data/images -l data/labels -m my_model.p -t data/test_images -o out

NOTE:
If you are running the code on Windows OS, there is no further change. 
If running on Linux/Unix/MacOS, change the variable 'on_windows' to 'False' at bottom of the code (under [if __name__ == "__main__":])

