import cv2
import numpy as np
from glob import glob
import argparse
import os, time, math
import pickle as pkl
from skimage import feature
from sklearn import metrics
from sklearn.model_selection import train_test_split
# import tifffile
# from sklearn.feature_extraction.image import extract_patches_2d

# run: python3 9517_ML.py -i data/images -l data/labels -m my_model.p -t data/test_images -o data/out

def parse_args():

    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--train_image_dir" , help="Path to train images", required=True)
    parser.add_argument("-l", "--label_dir", help="Path to labels", required=True)
    parser.add_argument("-m", "--model_path", help="Path to save model. End with .p", required = True)
    parser.add_argument("-t", "--test_image_dir" , help="Path to test images", required=True)
    parser.add_argument("-o", "--output_dir", help="Path to output directory", required = True)
    args = parser.parse_args()

    # validate the arguments
    if not os.path.exists(args.train_image_dir):
        raise ValueError("Train image directory does not exist", args.image_dir)
    if not os.path.exists(args.label_dir):
        raise ValueError("Label directory does not exist")
    if args.model_path.split('.')[-1] != "p":
        raise ValueError("Model should end with .p")
    if not os.path.exists(args.test_image_dir):
        raise ValueError("Test image directory does not exist")
    if not os.path.exists(args.output_dir):
        raise ValueError("Output directory does not exist")
    return args

def read_data(image_dir, label_dir, on_windows):

    print ('[INFO] Reading image data.')
    filelist = glob(os.path.join(image_dir, '*.jpg'))
    image_list = []
    label_list = []

    for file in filelist:
        image_list.append(cv2.imread(file, 1))
        if on_windows:
            labelname = file.split('\\')[-1][:5]+'-'+'labels'+file.split('\\')[-1][-6:]
        else:
            labelname = file.split('/')[-1][:5]+'-'+'labels'+file.split('/')[-1][-6:]
        tmp = cv2.imread(os.path.join(label_dir, labelname), 0)
        print(os.path.join(label_dir, labelname))
        label_list.append(tmp)

    return image_list, label_list

def calc_lbp_features(img, neigh, radius):

    lbp_features = feature.local_binary_pattern(img, neigh, radius, method="default") # method="uniform")

    return np.array(lbp_features)

def create_patches(img, size):
    if img is None:
        print('######### NO IMAGE! ##########')
    pat = []
    for i in range(0, img.shape[0]//size):
        for j in range(0, img.shape[0]//size):
            if len(img.shape) == 2:
                pat.append(img[i*size:i*size+size, j*size:j*size+size])
            else:
                pat.append(img[i*size:i*size+size, j*size:j*size+size, :])
    return np.array(pat)
    
def create_features(img, img_gray, label, train=True):

    radius = 16 # LBP radius
    neigh = radius * 8 # LBP number of neighbours
    num_examples = 15000 # number of examples per image to use for training model

    # print("image", img.shape)
    feature_img = np.zeros((img.shape[0],img.shape[1],4))
    feature_img[:,:,:3] = img

    lbp_features = calc_lbp_features(img_gray, neigh, radius)
    feature_img[:,:,3] = lbp_features

    # make patches of size = neigh*2
    # size = neigh
    # feat_patches = create_patches(feature_img, size)
    # print('patch shape:', feat_patches.shape)

    features = feature_img.reshape((feature_img.shape[0]*feature_img.shape[1], feature_img.shape[2]))
    # features = feat_patches.reshape((feat_patches.shape[0]*feat_patches.shape[1]*feat_patches.shape[2], feat_patches.shape[3]))
    # print('patch reshape shape:', features.shape)

    if train == True:
        subsamples = np.random.randint(0, features.shape[0], num_examples)
        features = features[subsamples]
        # features = features.reshape((features.shape[0], features.shape[1]*features.shape[2], features.shape[3]))
        print('feature shape:', features.shape)
    else:
        subsamples = []
        # features = feat_patches.reshape((feat_patches.shape[0]* feat_patches.shape[1]*feat_patches.shape[2], feat_patches.shape[3]))
    
    # labels = label.reshape(label.shape[0]*label.shape[1], 1)
    if train == True:
        # label_patches = create_patches(label, size)
        labels = label.reshape(label.shape[0]*label.shape[1], 1)
        labels = labels[subsamples]
        print('label shape:', labels.shape)
    else:
        labels = None
        
    return features, labels

def create_training_dataset(image_list, label_list):

    print ('[INFO] Creating training dataset on %d image(s).' %len(image_list))
    X = []
    y = []

    for i, img in enumerate(image_list):
        print (f'[INFO] Computing LBP features for image {i+1}/{len(image_list)}.')
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        features, labels = create_features(img, img_gray, label_list[i])
        X.append(features)
        y.append(labels)

    X = np.array(X)
    X = X.reshape(X.shape[0]*X.shape[1], X.shape[2])
    y = np.array(y)
    y = y.reshape(y.shape[0]*y.shape[1], y.shape[2]).flatten()
    print('==========================')
    print(X.shape, y.shape)
    # X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    # print ('[INFO] Feature vector size:', X_train.shape)

    return X, y

def train_model(X, y):

    classifier = 'rf'
    if classifier == "svm":
        from sklearn.svm import SVC
        print ('[INFO] Training Support Vector Machine model.')
        model = SVC(gamma='auto', verbose=True)
        model.fit(X, y)
    elif classifier == "rf":
        from sklearn.ensemble import RandomForestClassifier
        print ('[INFO] Training Random Forest model.')
        model = RandomForestClassifier(n_estimators=250, max_depth=15, min_samples_leaf=2, random_state=42,  verbose=2, n_jobs=-1)
        model.fit(X, y)

    print ('[INFO] Model training complete.')
    print ('[INFO] Training Accuracy: %.2f' %model.score(X, y))
    return model

def compute_prediction(img, model):

    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    features, _ = create_features(img, img_gray, label=None, train=False)
    predictions = model.predict(features.reshape(-1, features.shape[1]))
    pred_size = int(math.sqrt(features.shape[0]))
    predict_img = predictions.reshape(pred_size, pred_size)
    print('predicted image shape: %sx%s' %(predict_img.shape[0], predict_img.shape[1]))

    return predict_img

def main(on_windows, train_image_dir, label_dir, model_path, test_image_dir, output_dir):

    start = time.time()

    image_list, label_list = read_data(train_image_dir, label_dir, on_windows)
    print(len(label_list))
    # print(label_list[0].shape)

    ############### Train the model using train images ###############
    X_train, y_train = create_training_dataset(image_list, label_list)
    model = train_model(X_train, y_train)
    pkl.dump(model, open(model_path, "wb"))
    print ('Processing time:',time.time()-start)

    ############# predict the test images #############
    testlist = glob(os.path.join(test_image_dir,'*.jpg'))

    print ('[INFO] Running prediction on %s test images' %len(testlist))
    # model = pkl.load(open( model_path, "rb" ) )

    for file in testlist:
        print ('[INFO] Processing images:', os.path.basename(file))
        predict_img = compute_prediction(cv2.imread(file, 1), model)
        cv2.imwrite(os.path.join(output_dir, os.path.basename(file)), predict_img)

        # img = item[:,:,0].astype('float32')
        # tiff_list = img
        # tifffile.imsave(save_path + '/%d_predict.tif'%i, tiff_list)


if __name__ == "__main__":
    args = parse_args()
    train_image_dir = args.train_image_dir
    label_dir = args.label_dir
    model_path = args.model_path

    test_image_dir = args.test_image_dir
    output_dir = args.output_dir

    on_windows = True
    # train_image_dir = "data\\images"
    # label_dir = "data\\labels"
    # model_path = "my_model.p"
    # test_image_dir = "data\\test_images"
    # output_dir = "data\\out"
    main(on_windows, train_image_dir, label_dir, model_path, test_image_dir, output_dir)
