################################################
For Haralick&LBP with SVM part code -- 
RF_Haralick_LBP.py
#####################################################

Note:
It is based on Xiao Tan's(z3413898) code,and added Haralick features

1. Run RF_Haralick_LBP by python RF_Haralick_LBP.py
2. The path of input images, labels, test images folder and output folder need to changed at the bottom of the code when you run.
Libariy Requirment:
1. cv2
2. numpy
3. pylab
4. glob
5. argparse
6. Os
7. pickle
8. progressbar
9. numpy.lib
10. skimage
11. sklearn
12. time
13. re
14. mahotas
15. math

##############################
SVM.ipynb for the SVM part

Note:
It is based on Guanqun Zhou's(z5174741) code, but extracted different new features 
Run this file in Jupiter Notebooks

Libariy Requirment:
1. Pandas
2. Numpy
3. skimage
4. Scikit-learn
5. scipy
6.itertools


Input Data set Requirements:
1. All input images should be .jpg file
2. For RF part, the datasets should be divided into test images and train images, so the labels
3. Because the path provided above is only useful to use on my laptop, it needs to be changed when ran on other computer. 

Output:
A well trained model for prediction
Production outputs of model