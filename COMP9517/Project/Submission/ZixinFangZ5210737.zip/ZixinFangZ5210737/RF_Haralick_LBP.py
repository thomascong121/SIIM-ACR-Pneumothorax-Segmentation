import cv2
import numpy as np
import pylab as plt
from glob import glob
import argparse
import os
import progressbar
import pickle as pkl
from numpy.lib import stride_tricks
from skimage import feature
from sklearn import metrics
from sklearn.model_selection import train_test_split
import time
import re
import math
import mahotas as mt

def read_data(image_dir, label_dir, on_windows):
    
    print ('[INFO] Reading image data.')
    
    filelist = glob(os.path.join(image_dir, '*.jpg'))
    image_list = []
    label_list = []
    
    for file in filelist:
        tele = re.compile(r"(.*)-(\D*)(\d*)")
        
        cc = tele.match(file)
        indexs = cc.group(3)
        
        image_list.append(cv2.imread(file, 1))
        label_list.append(cv2.imread(os.path.join(label_dir, "train-labels"+indexs+'.jpg'), 0))
    
    return image_list, label_list


def calc_haralick(roi):
    
    feature_vec = []
    
    texture_features = mt.features.haralick(roi)
    mean_ht = texture_features.mean(axis=0)
    
    [feature_vec.append(i) for i in mean_ht[0:9]]
    
    return np.array(feature_vec)

def harlick_features(img, h_neigh, ss_idx):
    
    print ('[INFO] Computing haralick features.')
    size = h_neigh
    shape = (img.shape[0] - size + 1, img.shape[1] - size + 1, size, size)
    strides = 2 * img.strides
    patches = stride_tricks.as_strided(img, shape=shape, strides=strides)
    
    patches = patches.reshape(-1, size, size)
    
    if len(ss_idx) == 0 :
        bar = progressbar.ProgressBar(maxval=len(patches), \
                                      widgets=[progressbar.Bar('=', '[', ']'), ' ', progressbar.Percentage()])
    else:
        bar = progressbar.ProgressBar(maxval=len(ss_idx), \
                                      widgets=[progressbar.Bar('=', '[', ']'), ' ', progressbar.Percentage()])

    bar.start()

    h_features = []

    if len(ss_idx) == 0:
        for i, p in enumerate(patches):
            bar.update(i+1)
            h_features.append(calc_haralick(p))
    else:
        for i, p in enumerate(patches[ss_idx]):
            bar.update(i+1)
            h_features.append(calc_haralick(p))


    return np.array(h_features)

def calc_lbp_features(img, neigh, radius):

    lbp_features = feature.local_binary_pattern(img, neigh, radius, method="default") # method="uniform")

    return np.array(lbp_features)

def create_patches(img, size):
    if img is None:
        print('######### NO IMAGE! ##########')
    pat = []
    for i in range(0, img.shape[0]//size):
        for j in range(0, img.shape[0]//size):
            if len(img.shape) == 2:
                pat.append(img[i*size:i*size+size, j*size:j*size+size])
            else:
                pat.append(img[i*size:i*size+size, j*size:j*size+size, :])
    return np.array(pat)
    
def create_features(img, img_gray, label, train=True):

    radius = 16 # LBP radius
    neigh = radius * 8 # LBP number of neighbours
    num_examples = 15000 # number of examples per image to use for training model
    h_neigh = 11 # haralick neighbourhood
    h_ind = int((h_neigh - 1)/ 2)
    
    # print("image", img.shape)
    feature_img = np.zeros((img.shape[0],img.shape[1],4))
    feature_img[:,:,:3] = img

    lbp_features = calc_lbp_features(img_gray, neigh, radius)
    feature_img[:,:,3] = lbp_features

    feature_img = feature_img[h_ind:-h_ind, h_ind:-h_ind]
    features = feature_img.reshape(feature_img.shape[0]*feature_img.shape[1], feature_img.shape[2])
    
    if train == True:
        ss_idx = np.random.randint(0, features.shape[0], num_examples)
        features = features[ss_idx]
    else:
        ss_idx = []

    h_features = harlick_features(img_gray, h_neigh, ss_idx)
    features = np.hstack((features, h_features))

    if train == True:
    
        label = label[h_ind:-h_ind, h_ind:-h_ind]
        labels = label.reshape(label.shape[0]*label.shape[1], 1)
        labels = labels[ss_idx]
    else:
        labels = None
    
    return features, labels


def create_training_dataset(image_list, label_list):

    print ('[INFO] Creating training dataset on %d image(s).' %len(image_list))
    X = []
    y = []

    for i, img in enumerate(image_list):
        print (f'[INFO] Computing LBP features for image {i+1}/{len(image_list)}.')
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        features, labels = create_features(img, img_gray, label_list[i])
        X.append(features)
        y.append(labels)

    X = np.array(X)
    X = X.reshape(X.shape[0]*X.shape[1], X.shape[2])
    y = np.array(y)
    y = y.reshape(y.shape[0]*y.shape[1], y.shape[2]).flatten()
    print('==========================')
    print(X.shape, y.shape)

    return X, y

def train_model(X, y):

    classifier = 'rf'
    if classifier == "svm":
        from sklearn.svm import SVC
        print ('[INFO] Training Support Vector Machine model.')
        model = SVC(gamma='auto', verbose=True)
        model.fit(X, y)
    elif classifier == "rf":
        from sklearn.ensemble import RandomForestClassifier
        print ('[INFO] Training Random Forest model.')
        model = RandomForestClassifier(n_estimators=250, max_depth=15, min_samples_leaf=2, random_state=42,  verbose=2, n_jobs=-1)
        model.fit(X, y)

    print ('[INFO] Model training complete.')
    print ('[INFO] Training Accuracy: %.2f' %model.score(X, y))
    return model

def compute_prediction(img, model):

    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    features, _ = create_features(img, img_gray, label=None, train=False)
    predictions = model.predict(features.reshape(-1, features.shape[1]))
    pred_size = int(math.sqrt(features.shape[0]))
    predict_img = predictions.reshape(pred_size, pred_size)
    print('predicted image shape: %sx%s' %(predict_img.shape[0], predict_img.shape[1]))

    return predict_img

def main(on_windows, train_image_dir, label_dir, model_path, test_image_dir, output_dir):

    start = time.time()

    image_list, label_list = read_data(train_image_dir, label_dir, on_windows)
    #print(len(label_list))
    # print(label_list[0].shape)

    ############### Train the model using train images ###############
    X_train, y_train = create_training_dataset(image_list, label_list)
    model = train_model(X_train, y_train)
    pkl.dump(model, open(model_path, "wb"))
    print ('Processing time:',time.time()-start)

    ############# predict the test images #############
    testlist = glob(os.path.join(test_image_dir,'*.jpg'))

    print ('[INFO] Running prediction on %s test images' %len(testlist))
    # model = pkl.load(open( model_path, "rb" ) )

    for file in testlist:
        print ('[INFO] Processing images:', os.path.basename(file))
        predict_img = compute_prediction(cv2.imread(file, 1), model)
        cv2.imwrite(os.path.join(output_dir, os.path.basename(file)), predict_img)


if __name__ == "__main__":
    train_image_dir = "/Users/fangzixin/Desktop/COMP9517_Project/train_image"
    label_dir = "/Users/fangzixin/Desktop/COMP9517_Project/train_label"
    model_path = "/Users/fangzixin/Desktop/COMP9517_Project/RF_Hara_LBP.p"
    test_image_dir = "/Users/fangzixin/Desktop/COMP9517_Project/test_image"
    output_dir = "/Users/fangzixin/Desktop/COMP9517_Project/output"
    on_windows = False
    main(on_windows, train_image_dir, label_dir, model_path, test_image_dir, output_dir)
